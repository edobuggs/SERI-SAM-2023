/***************************************************************************
**
** File: i860.c - Example 1 board program
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This will implement the board portion of the example 1 program
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*
 * Shared string with host.
 */
char hwstring[80] 	= "not set yet";

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: symbol reference
**
**  Description:
**  This is required for board application to link properly - all programs
**	need a 'main' procedure.
**
****************************************************************************/
void main( void )
{
}

/****************************************************************************
**
**  EXPORT - hw: Invoked by host to alter string contents
**
**  Description:
**	This is invoked by the host to illustrate that simple RPC and shared
**	data concepts.
**
****************************************************************************/
void hw( void )
{
	printf( "i860 before: %s\n", hwstring );
	strcpy( hwstring, "Hello World" );
	printf( "i860 after:  %s\n", hwstring );
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
