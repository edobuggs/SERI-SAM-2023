/***************************************************************************
**
** File: ex1ctrl.c - Host control program for example 1
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This will illustrate the initial RPC interface: alcall 
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "allib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*
 * ALACRON device specifier
 */
#define AL_DEV			0

/*
 * I860 program to download
 */
#define I860PROGRAM		"ex1"

/*
 * Default stack size
 */
#define STACKSIZE		(64L * 1024L)

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: Program to download and execute i860 program
**
**  Description:
** 	This will open and select a device, download a simple program and
**	check a shared string before and after the alcall invocation.
**
****************************************************************************/
int main( void )
{
	ADDR 	A_hw;
	ADDR 	A_hwstring;
	char 	buf[80];

	if (alopen( AL_DEV ) != SUCCESS)
		errexit( "Can't open AL860 device %d\n", AL_DEV );
	if (aldev( AL_DEV ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit( "Can't select device %d\n", AL_DEV ); 
	}

	if (almapload( I860PROGRAM, STACKSIZE ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit ("Can't load %s\n", I860PROGRAM);
	}

	A_hw = aladdr ("_hw");
	if (A_hw == (ADDR)0) {
		(void)alclose( AL_DEV );
		errexit ("Can't find function _hw\n" );
	}

	A_hwstring = aladdr( "_hwstring" );
	if (A_hw == (ADDR)0) {
		(void)alclose( AL_DEV );
		errexit ("Can't find shared symbol _hwstring\n" );
	}
	A_hwstring = VtoP( A_hwstring );		/* Convert to physical address */

	algetba( A_hwstring, buf, sizeof(buf) );
	printf( "host before: %s\n", buf );

	alcall( A_hw, 0 );
	alwait( );

	algetba( A_hwstring, buf, sizeof(buf) );
	printf( "host after: %s\n", buf );

	alclose( AL_DEV );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
