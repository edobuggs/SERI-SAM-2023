/***************************************************************************
**
** File: ex2.c: Provides various routines for host to interact with
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This module provides a series of simple functions for the host to 
** invoke to show how the various return code types can be retrieved 
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: symbol reference
**
**  Description:
**  This is required for board application to link properly - all programs
**	need a 'main' procedure.
**
****************************************************************************/
void main( void )
{
}

/****************************************************************************
**
**  EXPORT - fint: Add a series of integers, return result
**
**  Description:
**	This will add up the integer arguments passed and return the result
**	as a 32 bit integer
**
****************************************************************************/
int fint ( int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, 
		   int arg7, int arg8, int arg9, int arg10)
{
	return arg1 + arg2 + arg3 + arg4 + arg5 + arg6 + arg7 + arg8 + arg9 + arg10;
}

/****************************************************************************
**
**  EXPORT - ffloat: Add a series of integers, return as a 32 bit float
**
**  Description:
**	This will add up the integer arguments passed and return the result
**	as a 32 bit float
**
****************************************************************************/
float ffloat ( int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, 
			   int arg7, int arg8, int arg9, int arg10) {
	return (float)arg1 + (float)arg2 + (float)arg3 + (float)arg4 + 
		   (float)arg5 + (float)arg6 + (float)arg7 + (float)arg8 + 
		   (float)arg9 + (float)arg10;
}

/****************************************************************************
**
**  EXPORT - fdouble: Add a series of integers, return as a 64 bit float
**
**  Description:
**	This will add up the integer arguments passed and return the result
**	as a 64 bit double precision float
**
****************************************************************************/
double fdouble ( int arg1, int arg2, int arg3, int arg4, int arg5, int arg6, 
				 int arg7, int arg8, int arg9, int arg10) 
{
	return (double)arg1 + (double)arg2 + (double)arg3 + (double)arg4 + 
		   (double)arg5 + (double)arg6 + (double)arg7 + (double)arg8 + 
		   (double)arg9 + (double)arg10;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
