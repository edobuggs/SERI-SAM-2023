/***************************************************************************
**
** File: ex2ctrl.c - Host control program for example 2
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This will illustrate the initial RPC interface: alcall & alget?result
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "allib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*
 * ALACRON device specifier
 */
#define AL_DEV			0

/*
 * I860 program to download
 */
#define I860PROGRAM		"ex2"

/*
 * Default stack size
 */
#define STACKSIZE		(64L * 1024L)

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: Program to download and execute i860 program
**
**  Description:
**	This will illustrate how to invoke functions and get integer, floating
**	point or double precision results.
**
****************************************************************************/
int main( void )
{
	if (alopen (AL_DEV) != SUCCESS)
		errexit( "Can't open AL860 device %d\n", AL_DEV );
	if (aldev( AL_DEV ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit( "Can't select device %d\n", AL_DEV ); 
	}

	if (almapload( I860PROGRAM, STACKSIZE ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit ("Can't load %s\n", I860PROGRAM);
	}

	alcall( aladdr ("_fint"), 10, 1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L, 9L, 10L );
	alwait( );
	printf( "fint returned:    %d\n", algetiresult() );

	alcall( aladdr ("_ffloat"), 10, 1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L, 9L, 10L);
	alwait( );
	printf( "ffloat returned:  %.2f\n", algetfresult() );

	alcall( aladdr ("_fdouble"), 10, 1L, 2L, 3L, 4L, 5L, 6L, 7L, 8L, 9L, 10L);
	alwait( );
	printf( "fdouble returned: %.2f\n", algetdresult() );

	alclose( AL_DEV );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
