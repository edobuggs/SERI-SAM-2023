/***************************************************************************
**
** File: ex3.c: Simple dot product implementation
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** Provides a simple dot product implementation, illustrates use of
** invoking multiple functions on the board - including standard C 
** runtime functions (malloc)
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: symbol reference
**
**  Description:
**  This is required for board application to link properly - all programs
**	need a 'main' procedure.
**
****************************************************************************/
void main( void )
{
	/*
	 * This reference ensures that the 'malloc' code is included in the
	 * executable image so that the the host can invoke it.
	 */
	malloc();
}

/****************************************************************************
**
**  EXPORT - dotpr: Simple dot product implementation
**
**  Description:
**	This will compute the dot product of p1 and p2, for length n, using
**	strides s1 and s2 to index p1 & p2 respectively; the result is stored
**	in *p3.
**
****************************************************************************/
void dotpr( float *p1, int s1, float *p2, int s2, float *p3, int n )
{
	float sum = 0.0;

	while (n --) {
		sum += *p1 * *p2;
		p1 += s1;
		p2 += s2;
	}
	*p3 = sum;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
