/***************************************************************************
**
** File: ex3ctrl.c - Host control program for example 3
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This will illustrate the initial RPC interface: alcall, alwait, algetiresult
** Used to show how standard library calls can be invoked from the host.
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "allib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*
 * ALACRON device specifier
 */
#define AL_DEV			0

/*
 * I860 program to download
 */
#define I860PROGRAM		"ex3"

/*
 * Default stack size
 */
#define STACKSIZE		(64L * 1024L)

/*
 * Size of dot product to perform
 */
#define N				1024

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*
 * Buffer used to store value into for host to copy to board
 */
float 					buf[N];

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void fetch_some_data( float *buf, int n );
static ADDR i860malloc( long n );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: Program to download and execute i860 program
**
**  Description:
**	Illustrates how host applications can invoke arbitrary library functions
**	and utilize the results.
**
****************************************************************************/
int main( void )
{
	ADDR A_buf1;
	ADDR A_buf2;
	ADDR A_result;
	ADDR A_dotpr;
	float result;

	if (alopen (AL_DEV) != SUCCESS)
		errexit( "Can't open AL860 device %d\n", AL_DEV );
	if (aldev( AL_DEV ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit( "Can't select device %d\n", AL_DEV ); 
	}

	if (almapload( I860PROGRAM, STACKSIZE ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit ("Can't load %s\n", I860PROGRAM);
	}

	/*--- Allocate data/arrays ---*/

	A_buf1 = i860malloc( (long)N * sizeof(float) );
	A_buf2 = i860malloc( (long)N * sizeof(float) );
	A_result = i860malloc( (long)sizeof(float) );

	/*--- Fetch some data, write to i860 ---*/

	fetch_some_data( buf, N );
	alsetla( VtoP( A_buf1 ), (long *)buf, N );
	fetch_some_data( buf, N );
	alsetla( VtoP( A_buf2 ), (long *)buf, N );

	/*--- Call dot product ---*/

	A_dotpr = aladdr( "_dotpr" );
	alcall( A_dotpr, 6, A_buf1, 1L, A_buf2, 1L, A_result, (long)N );
	alwait( );

	algetla( VtoP( A_result ), (long *)&result, 1 );

	printf( "Result: %.4f\n", result );

	alclose( AL_DEV );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - fetch_some_data: Create sample data into buffer provided
**
**  Description:
**	This simply stores some sample data into the buffer provided.
**
****************************************************************************/
static void fetch_some_data( float *buf, int n )
{
	int i;

	for (i = 0; i < n; i++)
		buf[i] = (float)2.0;
}

/****************************************************************************
**
**  PRIVATE - i860malloc: Allocate some data on the currently selected dev
**
**  Description:
**	This will allocate some on-board data for use by the dotpr code. It
**	returns an i860 virtual address suitable for use by the on-board 
**	processor.
**
****************************************************************************/
static ADDR i860malloc( long n )
{
	alcall( aladdr ("_malloc"), 1, n );
	alwait( );
	return algetiresult( );
}
