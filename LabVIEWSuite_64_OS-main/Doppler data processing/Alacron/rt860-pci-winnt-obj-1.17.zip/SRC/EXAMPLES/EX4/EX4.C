/***************************************************************************
**
** File: ex4.c: Simple dual processor board code 
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This provides two functions which are invoked on different processors
** from the host.
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: symbol reference
**
**  Description:
**  This is required for board application to link properly - all programs
**	need a 'main' procedure.
**
****************************************************************************/
void main( void )
{
}

/****************************************************************************
**
**  EXPORT - fctn1: Returns the float square of the integer argument
**
**  Description:
**	This returns a 32 bit floating point value for the square of the
**	32 bit integer passed.
**
****************************************************************************/
float fctn1( int i )
{
	return (float)i * (float)i;
}

/****************************************************************************
**
**  EXPORT - fctn2: Returns the float cube of the integer argument
**
**  Description:
**	This returns a 32 bit floating point value for the cube of the
**	32 bit integer passed.
**
****************************************************************************/
float fctn2( int i )
{
	return (float)i * (float)i * (float)i;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
