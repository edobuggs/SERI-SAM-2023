/***************************************************************************
**
** File: ex4ctrl.c - Host control program for example 4
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** Used to show how both processors can be invoked from the host via mpcall.
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "allib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*
 * ALACRON device specifier
 */
#define AL_DEV			0

/*
 * I860 program to download
 */
#define I860PROGRAM		"ex4"

/*
 * Default stack size
 */
#define STACKSIZE		(64L * 1024L)

/*
 * Number of iterations to run test
 */
#define N_ITER			10

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: Program to download and execute i860 program
**
**  Description:
**	This will handle N_ITER iterations of function calls to each processor,
**	and displaying the results of some simple board calculations.
**
****************************************************************************/
int main( void )
{
	ADDR 	A_fctn1;
	ADDR 	A_fctn2;
	long 	retmask;
	long 	fctn1count = 0;
	long 	fctn2count = 0;

	if (alopen( AL_DEV ) != SUCCESS)
		errexit( "Can't open AL860 device %d\n", AL_DEV );
	if (aldev( AL_DEV ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit( "Can't select device %d\n", AL_DEV ); 
	}

	if (almapload( I860PROGRAM, STACKSIZE ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit( "Can't load %s\n", I860PROGRAM );
	}

	/*--- Fetch addresses ---*/

	A_fctn1 = aladdr( "_fctn1" );
	A_fctn2 = aladdr( "_fctn2" );

	/*--- Invoke functions ---*/

	mpcall( 0, A_fctn1, 1, fctn1count );
	mpcall( 1, A_fctn1, 1, fctn2count );

	/*--- Keep handling calls to the board ---*/

	while ((fctn1count < N_ITER) || (fctn2count < N_ITER))
	{
		retmask = mpwait( );
		
		if (retmask & 1)			/* proc 0 ? */
		{
			printf( "proc 0: %.2f\n", mpgetfresult(0) );
			if (++fctn1count < N_ITER)
				mpcall( 0, A_fctn1, 1, fctn1count );
		}

		if (retmask & 2)			/* proc 1 ? */
		{
			printf( "proc 1: %.2f\n", mpgetfresult(1) );
			if (++fctn2count < N_ITER)
				mpcall( 1, A_fctn2, 1, fctn2count );
		}
	}

	alclose( AL_DEV );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
