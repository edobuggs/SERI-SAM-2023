/***************************************************************************
**
** File: ex5.c: example 5: Shows interaction with periodic interrupts (RTC)
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This is the board side code for illustrating interactions with the
** RTC driver.
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*
 * Number of ticks our handler has seen
 */
int 	usercount = 0;

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void rtcint( void );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: symbol reference
**
**  Description:
**  This is required for board application to link properly - all programs
**	need a 'main' procedure.
**
****************************************************************************/
void main( void )
{
}

/****************************************************************************
**
**  EXPORT - rtcset: Setup to handle RTC interrupts at desired rate
**
**  Description:
**	This will setup the RTC to generate periodic interrupts tha are handled
**	by the function rtcinit. The function takes a desired frequency to 
**	be setup, and returns the actual approximation of the number of 
**	interrupts received per second.
**
****************************************************************************/
float rtcset( int ifreq )
{
	float	rfreq;
	int 	startcount = 10000;

	/*
	 * Set desired RTC frequency
	 * Set counter
	 * Attach interrupt handler
	 * Enable interrupts
	 * Fetch actual frequency
	 * Return real frequency
	 */
	rtcioctl( RTC_SETFREQ, ifreq );
	rtcioctl( RTC_SETCOUNT, &startcount );
	rtcioctl( RTC_ATTACHINT, rtcint );
	rtcioctl( RTC_ENABLE );
	rtcioctl( RTC_GETFREQ, &rfreq );

	return rfreq;
}

/****************************************************************************
**
**  EXPORT - getdrvcount: Return current number of clock ticks 
**
**  Description:
**	This returns the current RTC driver count tick value
**
****************************************************************************/
int getdrvcount( void )
{
	int count;

	rtcioctl( RTC_GETCOUNT, &count );

	return count;
}

/****************************************************************************
**
**  EXPORT - getusrcount: Return number of ticks seen by our RTC handler
**
**  Description:
**	This returns the current number of interrupts our handler has seen
**
****************************************************************************/
int getusrcount( void )
{
	return usercount;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - rtcint: RTC interrupt handler
**
**  Description:
**	This is invoked on each clock interrupt, and increments the number
**	of interrupts our handler has seen
**
****************************************************************************/
static void rtcint( void ) 
{
	usercount++;
}
