/***************************************************************************
**
** File: ex5ctrl.c - Host control program for example 5
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** Illustrates how to interact with the RTC driver on the board.
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "allib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*
 * ALACRON device specifier
 */
#define AL_DEV			0

/*
 * I860 program to download
 */
#define I860PROGRAM		"ex5"

/*
 * Default stack size
 */
#define STACKSIZE		(64L * 1024L)

/*
 * Desired RTC interrupt frequency
 */
#define DESIRED_FREQ	200L

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

#if defined(MSDOS) || defined(OS2) || defined( WIN95 ) || defined( WIN311 )
static void sleep( int n );
#endif

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: Program to download and execute i860 program
**
**  Description:
**	This will download the board program, and set it up to generate
**	periodic interrupts through the RTC driver. 
**
****************************************************************************/
int main( void )
{
	float 	actual_frequency;

	if (alopen( AL_DEV ) != SUCCESS)
		errexit( "Can't open AL860 device %d\n", AL_DEV );
	if (aldev( AL_DEV ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit( "Can't select device %d\n", AL_DEV ); 
	}

	if (almapload( I860PROGRAM, STACKSIZE ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit( "Can't load %s\n", I860PROGRAM );
	}

	alcall( aladdr( "_rtcset" ), 1, DESIRED_FREQ );
	alwait( );
	actual_frequency = algetfresult( );
	printf( "Actual frequency:  %.4f Hz\n", actual_frequency );

	sleep( 5 );
	
	alcall( aladdr("_getdrvcount"), 0 );
	alwait( );
	printf( "RTC driver count:  %6d\n", algetiresult() );

	alcall( aladdr("_getusrcount"), 0 );
	alwait( );
	printf( "User count:        %6d\n", algetiresult() );

	alclose( AL_DEV );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

#if defined(MSDOS) || defined(OS2) || defined( WIN95 ) || defined( WIN311 )
/****************************************************************************
**
**  PRIVATE - sleep: Pauses host for specified number of seconds
**
**  Description:
**	This will perform a delay for the number of seconds requested
**
****************************************************************************/
static void sleep( int n )
{
	time_t	t, t1;

	t = time( &t1 );
	while ((time( &t1 ) - t) < n)
		;
}
#endif
