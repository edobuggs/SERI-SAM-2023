/***************************************************************************
**
** File: ex6.c: example 6 - Illustrates host to board interrupt handling
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This is used to show how host to board interrupt reception can be used.
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*
 * Number of host interrupts seen
 */
int 	count = 0;

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void atint( void );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: symbol reference
**
**  Description:
**  This is required for board application to link properly - all programs
**	need a 'main' procedure.
**
****************************************************************************/
void main( void )
{
}

/****************************************************************************
**
**  EXPORT - atcount: Return number of host interrupts board has seen
**
**  Description:
**	This returns the global value indicating how many host interrupts
**	have been processed.
**
****************************************************************************/
int atcount( void )
{
	return count;
}

/****************************************************************************
**
**  EXPORT - atset: Sets up the host interrupt reception function
**
**  Description:
**	This sets and enable the host interrupt reception function
**
****************************************************************************/
void atset( void )
{
	atioctl( AT_ATTACHINT, atint );
	atioctl( AT_ENABLE );
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - 
**
**  Description:
**
****************************************************************************/
static void atint( void )
{
	count++;
}
