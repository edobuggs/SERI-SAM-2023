/***************************************************************************
**
** File: ex6ctrl.c - Host control program for example 1
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This will illustrate the initial RPC interface: alcall 
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "allib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*
 * ALACRON device specifier
 */
#define AL_DEV			0

/*
 * I860 program to download
 */
#define I860PROGRAM		"ex6"

/*
 * Default stack size
 */
#define STACKSIZE		(64L * 1024L)

/*
 * Number of interrupts to generate
 */
#define NINTS_SENT		10L

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

#if defined(MSDOS) || defined(OS2) || defined( WIN95 ) || defined( WIN311 )
static void sleep( int n );
#endif

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: Program to download and execute i860 program
**
**  Description:
**	Downloads a program, and generate a series of interrupts which the
**	board can receive and process. We then retrieve the results and validate
**	against the actual number sent.
**
****************************************************************************/
int main( void )
{
	long	nints;

	if (alopen( AL_DEV ) != SUCCESS)
		errexit( "Can't open AL860 device %d\n", AL_DEV );
	if (aldev( AL_DEV ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit( "Can't select device %d\n", AL_DEV ); 
	}

	if (almapload( I860PROGRAM, STACKSIZE ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit( "Can't load %s\n", I860PROGRAM );
	}

	alcall( aladdr( "_atset" ), 0 );
	alwait( );
	
	for (nints = 0; nints < NINTS_SENT; nints++) {
		sleep( 1 );
		alinterrupt( AL_DEV );
	}

	alcall( aladdr( "_atcount" ), 0 );
	alwait( );
	nints = algetiresult();
	printf( "Host interrupts sent %ld, received %ld\n", NINTS_SENT, nints );

	alclose( AL_DEV );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

#if defined(MSDOS) || defined(OS2) || defined( WIN95 ) || defined( WIN311 )
/****************************************************************************
**
**  PRIVATE - sleep: Pauses host for specified number of seconds
**
**  Description:
**	This will perform a delay for the number of seconds requested
**
****************************************************************************/
static void sleep( int n )
{
	time_t	t, t1;

	t = time( &t1 );
	while ((time( &t1 ) - t) < n)
		;
}
#endif
