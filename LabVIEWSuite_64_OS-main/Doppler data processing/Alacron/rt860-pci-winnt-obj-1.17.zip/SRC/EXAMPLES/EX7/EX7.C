/***************************************************************************
**
** File: ex7.c: Knights tour program
**
** Copyright (C) 1992-1995; Alacron Inc.
**
** Description:
** This performs a dual processor knights tour demonstration: It fires
** off knight tours on both processors, and prints out the results. It 
** illustrates many of the mp concepts, including: mp_clock_val, 
** semaphores, mp_printf & thread control.
**
** History:
** ?? Feb 92, adb: Creation
** 16 Aug 95, adb: Reformatting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h> 
#include <stdlib.h>
#include <math.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*
 * Board dimensions & search depth
 */
#define NR 					8
#define CENTER				((double)(NR+2) / 2.0)
#define DEPTH				(NR*NR)

/*
 * Square holders
 */
#define INVALID				((unsigned long)0)
#define TAKEN				((unsigned long)1)
#define EMPTY				((unsigned long)2)

/*
 * Shorthands
 */
#define UMALLOC				umalloc
#define TICKS_PER_SECOND	((double)1000000.0)
#define PRINTF				mp_printf

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*--- Returns true if K will leave board ---*/

#define OUTSIDE( x )		(((x) < 2) || ((x) > (NR+1)))

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*--- A grid location on a board ---*/

typedef struct {
	unsigned long 			col;
	unsigned long 			row;
} Square;

/*
 * Offsets from any given square
 */
typedef struct {
	int 					row_off;
	int 					col_off;
} Offset;

/*--- The board as a rim for knights who wander ---*/

typedef unsigned long 		Board[NR+4][NR+4];

/*--- Distance from center table ---*/

typedef double 				Dist[NR+4][NR+4];

/*--- Thread library arguments ---*/

typedef struct {
	Board					board;
	void					*semp;
	Square					route[DEPTH];
	unsigned long			begin, delta;
	unsigned long			nodes;
	Square					start;
	int						proc;
} Arg;

/*----------------------- PRIVATE DATA ------------------------------------*/

/*
 * Distance table for quick calculations
 */
static Dist 				dist;

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static int tour( Arg *arg, unsigned long row, unsigned long col, int depth );
static void board_init( Arg *arg );
static void sort( Square attempts[8] );
static void make_attempts( Arg *arg, unsigned long row, unsigned long col, 
			   Square attempts[8] );
static void report( Square rte[DEPTH] );
static void doit( void *param );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main program: 
**
**  Description:
**	This will perform knights tours on both processors.
**
****************************************************************************/
int main( int argc, char *argv[], char *envp[] )
{
	int 	rval;
	int 	row, col;
	Arg		*arg0, *arg1;
	double	dr, dc;
	int		stepping;

	/*--- Must run on XP processors ---*/

	if (bi_query_cpu_type( &stepping ) != 2) {
		mp_errprintf( "Requires XP processor(s), exitting\n" );
		exit( 1 );
	}

	/*--- Initialize distances ---*/

	memset( dist, 0, sizeof( dist ) );
	for (row = 2; row < (NR+4); row++) for (col = 2; col < (NR+4); col++) {
		dr = (double)row - CENTER;
		dc = (double)col - CENTER;
		dist[row][col] = sqrt( (dr * dr) + (dc * dc) );
	}

	/*--- Setup thread arguments ---*/


	arg0 = (Arg *)mp_4meg_addr( UMALLOC( sizeof( Arg ) ), MP_KADDR_WBC );
	memset( arg0, 0, sizeof( Arg ) );
	arg1 = (Arg *)mp_4meg_addr( UMALLOC( sizeof( Arg ) ), MP_KADDR_WBC );
	memset( arg1, 0, sizeof( Arg ) );

	arg1->semp = arg0->semp = mp_sem_allocate();
	arg1->nodes = arg0->nodes = 0L;
	arg0->proc = 0;
	arg1->proc = 1;

	if (argc == 3) {
		sscanf( argv[1], "%i", &row );
		sscanf( argv[2], "%i", &col );
	}
	else
		row = col = 2;

	arg0->start.row = row; arg0->start.col = col;
	arg1->start.row = col; arg1->start.col = row; 

	/*--- Fire off the thread ---*/

	rtcioctl( RTC_SETFREQ, (long)0xffffffff );
	flush();	/* distance table */

	if (mp_thread_start( 1, doit, (void *)arg1 ) == 0) {

		/*--- Do this processors work ---*/

		doit( (void *)arg0 );

		/*--- Await the other processor ---*/

		if ((rval = mp_thread_query( 1, 1 )) != 2) {
			mp_errprintf("rval=%d from query\n",rval);
			exit(1);
		}
	}
	else {
		mp_errprintf("Could not start thread on processor 1\n"
					 "Will do it just on processor 0\n" );
		doit( (void *)arg0 );
	}

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - tour: Perform recursive tour
**
**  Description:
**	This is the actual recursive search routine: the idea is to see if there
**	exists a path from a given square that touches only empty squares to
**	the maximum depth achievable. Thus if the next square is empty, and we
**	are at the maximum depth we have a full path. If the next square is
**	not empty we are at the end of a path. If we are going to an empty 
**	square and we aren't at the end, we check for each possible next square
**	if there is a viable path to the end.
**
****************************************************************************/
static int tour( Arg *arg, unsigned long row, unsigned long col, int depth )
{
	Square 	attempts[8];
	int 	i;

	arg->nodes++;

	if (arg->board[row][col] != EMPTY) 
		return 0;

	depth++;
	arg->board[row][col] = TAKEN;

	if (depth == DEPTH) {

		/*--- Result found ---*/

		arg->delta = arg->begin - mp_clock_val(); /* Counts down */

		arg->route[depth-1].row = row;
		arg->route[depth-1].col = col;

		return 1;
	}
		
	make_attempts( arg, row, col, attempts );
	for (i = 0; i < 8; i++) {
		if (attempts[i].row == INVALID)
			continue;

		if (tour( arg, attempts[i].row, attempts[i].col, depth )) {

			arg->route[depth-1].row = row;
			arg->route[depth-1].col = col;

			return 1;
		}
	}

	arg->board[row][col] = EMPTY;
	return 0;
}

/****************************************************************************
**
**  PRIVATE - board_init: Initialize a board to all invalid or empty
**
**  Description:
**	This initializes a board so that the inner squares are empty, and the
**	squares outside of the board are marked invalid.
**
****************************************************************************/
static void board_init( Arg *arg )
{
	int i;
	int j;

	for (i = 0; i < (NR+4); i++) {
		arg->board[   i][   0] = INVALID;
		arg->board[   i][   1] = INVALID;
		arg->board[   i][NR+2] = INVALID;
		arg->board[   i][NR+3] = INVALID;
		arg->board[   0][   i] = INVALID;
		arg->board[   1][   i] = INVALID;
		arg->board[NR+2][   i] = INVALID;
		arg->board[NR+3][   i] = INVALID;
	}
	for (i = 2; i < (NR+2); i++)
		for (j = 2; j < (NR+2); j++)
			arg->board[i][j] = EMPTY;
}

/****************************************************************************
**
**  PRIVATE - sort: Distance sort to speed up path search
**
**  Description:
** 	  	Sort an array of attempted squares according to the heuristic
**		of choosing those moves which put the knight furthest from
**		the center of the board - using Pythagorean distances
**
****************************************************************************/
static void sort( Square attempts[8] )
{
	int 	i, j, k;
	double  d[8];
	double  dr;
	Square	tmp;

	/*--- Compute distance & sort ---*/

	if (attempts[0].row == INVALID)
		d[0] = (double)0.0;			/* Really close == sort last */ 
	else
		d[0] = dist[attempts[0].row][attempts[0].col];

	for (i = 1; i < 8; i++) {

		if (attempts[i].row == INVALID) {
			d[i] = (double)0.0;
			continue;
		}

		/*--- Sort (simple) ---*/

		d[i] = dist[attempts[i].row][attempts[i].col];
		for (j = 0; j < i; j++) {
			if( d[j] < d[i] ) {
				tmp = attempts[i];
				dr  = d[i];
				for (k = i; k > j; k--) {
					d[k] = d[k-1];
					attempts[k] = attempts[k-1];
				}
				attempts[j] = tmp;
				d[j] = dr;
				break;
			}
		}
	}
}

/****************************************************************************
**
**  PRIVATE - make_attempts: Make a list of possible N moves from this square
**
**  Description:
**		Produce a list of attempted squares for a knight at place
**		on board, prune list by not allowing off-board or already
**		encountered squares.
**
****************************************************************************/
static void make_attempts( Arg *arg, unsigned long row, unsigned long col, 
			   Square attempts[8] )
{
	static Offset offsets[ 8 ] = {
		{ -2,  1 }, 
		{ -2, -1 }, 
		{ -1, -2 }, 
		{ -1,  2 },
		{  2, -1 }, 
		{  2,  1 },
		{  1,  2 }, 
		{  1, -2 }
	};
	int i;
	int r, c;

	for (i = 0; i < 8; i++) {
		r = row + offsets[i].row_off;
		c = col + offsets[i].col_off;

		if ((OUTSIDE( r ) || OUTSIDE( c ) ) || (arg->board[r][c] != EMPTY))
			r = INVALID;

		attempts[i].col = c;
		attempts[i].row = r;
	}

	sort( attempts );
}

/****************************************************************************
**
**  PRIVATE - report: Display path for this tour
**
**  Description:
**	This will display the path (using the step number to indicate when
**	each square was reached).
**
****************************************************************************/
static void report( Square rte[DEPTH] )
{
	int i, j, k;

	PRINTF("\n");
	for (i = NR-1; i >= 0; i--) {
		for (j = 0; j < NR; j++) {
			for (k = 0; k < (NR*NR); k++) {
				if ((rte[k].row == (i+2)) && (rte[k].col == (j+2))) {
					PRINTF("%2d ", k);
					break;
				}
			}
		}
		PRINTF("\n");
	}
	PRINTF("\n");
}

/****************************************************************************
**
**  PRIVATE - doit: Per processor thread entry point
**
**  Description:
**	This will perform the work for a tour on this processor
**
****************************************************************************/
static void doit( void *param )
{
	Arg		*arg = (Arg *)param;
	char	rowchar, colchar;

	board_init( arg );
	arg->begin = mp_clock_val();

	colchar = (arg->start.col - 2) + 'a';
	rowchar = (arg->start.row - 2) + '1';
	PRINTF("Proc%d Start square = %c%c\n",arg->proc,colchar,rowchar);
	tour( arg, arg->start.row, arg->start.col, 0 );

	/*--- Report the results ---*/

	(void)mp_sem_acquire( arg->semp, MP_SEM_FOREVER );
	PRINTF("Proc %d processed %ld nodes, in %.6lf seconds\n",
		arg->proc, arg->nodes, (double)(arg->delta) / TICKS_PER_SECOND);
	report( arg->route );
	mp_sem_release( arg->semp );
}
