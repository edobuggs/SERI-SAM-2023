/***************************************************************************
**
** File: i860.c - Example 8 board program
**
** Copyright (C) 1997; Alacron Inc.
**
** Description:
** This will implement the board portion of the example 8 program
**
** History:
** 05 Mar 97, dcd: Creation.
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

#define DMABUFSIZE (500 * 1024)
/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

unsigned char dmabuf[DMABUFSIZE];

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: symbol reference
**
**  Description:
**  This is required for board application to link properly - all programs
**	need a 'main' procedure.
**
****************************************************************************/
void main( void )
{
}

/****************************************************************************
**
**
****************************************************************************/
void dmainvert( void )
{
	int i;

	for( i = 0; i < DMABUFSIZE; i++ )
	 {
		dmabuf[i] = ~dmabuf[i];
	 }

}
/****************************************************************************
**
**
****************************************************************************/
void dmabufcheck( void )
{
	int i;

	for( i = 0; i < DMABUFSIZE; i++ )
	 {
		if( dmabuf[i] != (char)(i & 0xFF) )
		 printf( "Failure at location %d %d\n", i, dmabuf[i] );
	 }

}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
