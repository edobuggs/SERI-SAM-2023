/***************************************************************************
**
** File: ex8ctrl.c - Host control program for example 8
**
** Copyright (C) 1997; Alacron Inc.
**
** Description:
** This will illustrate the DMA functionality for Windows NT.
**
** History:
** 05 Mar 97, dcd: Creation.
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/
#include <wtypes.h>
#include <stdlib.h>
#include "allib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*
 * ALACRON device specifier
 */
#define AL_DEV			0

/*
 * I860 program to download
 */
#define I860PROGRAM		"ex8"

/*
 * Default stack size
 */
#define STACKSIZE		(64L * 1024L)

/*
 * The size and rep count of the DMA
 */
#define DMASIZE			(500L  * 1024L)
#define DMAREPCNT		10
#define BPSREPCNT		1000

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/
BOOLEAN dmaCheckBuffer( PUCHAR pucBuffer, PULONG ulLocat );
float dmaXferCheckOut( PUCHAR pucBuffer, ADDR aAddr );
float dmaXferCheckIn( PUCHAR pucBuffer, ADDR aAddr );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/
int printf(const char *, ...);

/****************************************************************************
**
**  EXPORT - main: Program to download and execute i860 program
**
**  Description:
** 	This will open and select a device, download a simple program and
**	check a shared string before and after the alcall invocation.
**
****************************************************************************/
int main( void )
{
	ADDR 	A_dmacheck;
	ADDR 	A_dmainvert;
	ADDR 	A_dmabuf;
	int		i, ipass;
	char	*pucBuf, *pucTmpBuf;
	HGLOBAL hMem;
	ULONG	ulLocat;

	if (alopen( AL_DEV ) != SUCCESS)
		errexit( "Can't open AL860 device %d\n", AL_DEV );
	if (aldev( AL_DEV ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit( "Can't select device %d\n", AL_DEV ); 
	}

	if (almapload( I860PROGRAM, STACKSIZE ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit ("Can't load %s\n", I860PROGRAM);
	}

	A_dmacheck = aladdr ("_dmabufcheck");
	if (A_dmacheck == (ADDR)0) {
		(void)alclose( AL_DEV );
		errexit ("Can't find function _dmabufcheck\n" );
	}

	A_dmainvert = aladdr ("_dmainvert");
	if (A_dmainvert == (ADDR)0) {
		(void)alclose( AL_DEV );
		errexit ("Can't find function _dmainvert\n" );
	}

	A_dmabuf = aladdr( "_dmabuf" );
	if (A_dmabuf == (ADDR)0) {
		(void)alclose( AL_DEV );
		errexit ("Can't find shared symbol _dmabuf\n" );
	}
	A_dmabuf = VtoP( A_dmabuf );		/* Convert to physical address */

	hMem = GlobalAlloc( GMEM_FIXED | GMEM_ZEROINIT, DMASIZE );
	if( hMem == NULL)
	 printf( "GlobalAlloc Failure!\n" );
	else
	 {
		pucBuf = (char *)GlobalLock( hMem );
		if( pucBuf == NULL )
		 printf( "GlobalLock Failure!\n" );
		else
		 {
			for( ipass = 0; ipass < DMAREPCNT; ipass++ )
			 {
				pucTmpBuf = pucBuf;

				// Initialize the buffer.
				for( i = 0; i < DMASIZE; i++ )
				*pucTmpBuf++ = i;

				// Send it into the board.
				if( ioctl860( AL_DEV, I860_DMA_IN, (void *)pucBuf, (void *)A_dmabuf, DMASIZE ))
					printf( "The DMA_IN FAILED!\n" );
				else
				 {

					alcall( A_dmacheck, 0 );
					alwait( );
					alcall( A_dmainvert, 0 );
					alwait( );
					if( ioctl860( AL_DEV, I860_DMA_OUT, (void *)pucBuf, (void *)A_dmabuf, DMASIZE ))
						printf( "The DMA_OUT FAILED on pass #%d!\n", ipass );
					else
					 {
						if( dmaCheckBuffer( pucBuf, &ulLocat ) )
							printf( "Pass #%d Completed without errors.\n", ipass );
						 else
							printf( "The DMA from the board failed the data test at location %d\n", ulLocat );
					 }
				 }
			 }
			printf( "Transfered In at %.4f MBytes/Second.\n", dmaXferCheckIn( pucBuf, A_dmabuf ));
			printf( "Transfered Out at %.4f MBytes/Second.\n", dmaXferCheckOut( pucBuf, A_dmabuf ));
			GlobalUnlock( pucBuf );
			GlobalFree( hMem );
		 }
	}

	alclose( AL_DEV );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
 /****************************************************************************
**
**
****************************************************************************/
BOOLEAN dmaCheckBuffer( PUCHAR pucBuffer, PULONG ulLocat )
{
	int i;
	PUCHAR pucTmpPtr;

	for( i = 0, pucTmpPtr = pucBuffer; i < DMASIZE; i++, pucTmpPtr++ )
	 {
		if( *pucTmpPtr != (UCHAR)(~i & 0xFF) )
		 {
			*ulLocat = i;
			return( FALSE );
		 }
	 }
	return( TRUE );

}

/****************************************************************************
**
**
****************************************************************************/
float dmaXferCheckIn( PUCHAR pucBuffer, ADDR aAddr )
{
	long	lStartTime, lEndTime;
	float	fXferBPS, fInterTime;
	int i;

	lStartTime = time100( );

	for( i = 0; i < BPSREPCNT; i++ )
	 {
		// Send it into the board.
		if( ioctl860( AL_DEV, I860_DMA_IN, (void *)pucBuffer, (void *)aAddr, DMASIZE ))
		 {
			printf( "The DMA_IN FAILED!\n" );
			return( (float)0.0 );
		 }
	 }
	lEndTime = time100( );
	fInterTime =(float)lEndTime - (float)lStartTime; 
	fXferBPS =  (float)(DMASIZE * BPSREPCNT) / fInterTime;
	return( fXferBPS / 10000 );

}

/****************************************************************************
**
**
****************************************************************************/
float dmaXferCheckOut( PUCHAR pucBuffer, ADDR aAddr )
{
	long	lStartTime, lEndTime;
	float	fXferBPS, fInterTime;
	int i;

	lStartTime = time100( );

	for( i = 0; i < BPSREPCNT; i++ )
	 {
		// Send it into the board.
		if( ioctl860( AL_DEV, I860_DMA_OUT, (void *)pucBuffer, (void *)aAddr, DMASIZE ))
		 {
			printf( "The DMA_OUT FAILED!\n" );
			return( (float)0.0 );
		 }
	 }
	lEndTime = time100( );
	fInterTime =(float)lEndTime - (float)lStartTime; 
	fXferBPS =  (float)(DMASIZE * BPSREPCNT) / fInterTime;
	return( fXferBPS / 10000 );

}
