/***************************************************************************
**
** File: mpex1.c - MP example 1 - thread start & query routines
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This is a simple illustration of a thread start & query, as well as
** mp_printf
**
** History:
** 16 Aug 95, adb: Commenting 
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void remote_function( void *param );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: Thread start & query routine
**
**  Description:
**	Starts a remote function on processor 1 and waits for completion
**
****************************************************************************/
int main( void )
{
	int res;
	int	stepping;

	/*--- Must run on XP processors ---*/

	if (bi_query_cpu_type( &stepping ) != 2) {
		mp_printf( "This requires XP processors to illustrate, exitting\n" );
		exit( 1 );
	}

	/*--- Start thread ---*/

	res = mp_thread_start( 1, remote_function, (void *)2 );
	mp_assert( res == 0 );

	/*--- Wait for completion ---*/

	mp_thread_query( 1, 1 );

	mp_printf( "Done\n" );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - remote_function: Display parameter & processor id
**
**  Description:
**	Displays processor number and parameter passed.
**
****************************************************************************/
static void remote_function( void *param )
{
	/*--- Processor 1: print something ---*/

	mp_printf( "Processor %d received arg %d\n", mp_proc_id(), (int)param);
}
