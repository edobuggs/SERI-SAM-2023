/***************************************************************************
**
** File: mpex2.c: Illustrate need for mutual exclusion
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** Illustrates need for mutual exclusion, as both processors increment
** stale copies of the shared global variable
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*
 * Number of iterations to perform
 */
#define NTIMES		10000

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*
 * Global counter
 */
unsigned long 		count = 0;

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void loop( void *param );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: illustrates need for mutual exclusion
**
**  Description:
**	This kicks off two threads of execution, where each increments a common
** 	location without mutual exclusion. The expected result and actual
**	are displayed.
**
****************************************************************************/
int main( void )
{
	int res;
	int	stepping;

	/*--- Must run on XP processors ---*/

	if (bi_query_cpu_type( &stepping ) != 2) {
		mp_printf( "This requires XP processors to illustrate, exitting\n" );
		exit( 1 );
	}

	/*--- start thread on P1 ---*/

	res = mp_thread_start( 1, loop, (void *)NTIMES );
	mp_assert( res == 0 );

	/*--- perform P0's share of work ---*/

	loop( (void *)NTIMES );

	/*--- wait for P1 to complete ---*/

	mp_thread_query( 1, 1 );

	/*--- display results ---*/

	mp_printf( "Count %d - should be %d\n", count, 2*NTIMES );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - loop: Increment a common counter 'n' times
**
**  Description:
**	This will increment a common variable the number of times requsted. 
**	We use the bi_set32/bi_deref32 functions to override any compiler
**	optimizations.
**
****************************************************************************/
static void loop( void *param )
{
	int 	i;
	int 	n = (int) param;

	for (i = 0; i < n; i ++)
		bi_set32( &count, bi_deref32( &count ) + 1 );
}
