/***************************************************************************
**
** File: mpex3.c: Illustrate proper use of mutual exclusion
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** Illustrates proper mutual exclusion techniques
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

#define NTIMES			10000

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*
 * Global counter
 */
unsigned long 			count = 0;

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void loop( void *mutex );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: This illustrates the proper use of synchronisation 
**
**  Description:
**	Used to show how semaphores can be used to properly synchronize access
**	rights to shared data.
**
****************************************************************************/
int main( void )
{
	void	*mutex;
	int 	res;
	int		stepping;

	/*--- Must run on XP processors ---*/

	if (bi_query_cpu_type( &stepping ) != 2) {
		mp_printf( "This requires XP processors to illustrate, exitting\n" );
		exit( 1 );
	}

	/*--- Create mutex semaphore ---*/

	mutex = mp_sem_allocate( );
	mp_assert( mutex != NULL );

	/*--- start thread on P1 ---*/

	res = mp_thread_start( 1, loop, mutex );
	mp_assert( res == 0 );

	/*--- perform P0's share of work ---*/

	loop( mutex );

	/*--- wait for P1 to complete ---*/

	mp_thread_query( 1, 1 );

	/*--- display results ---*/

	mp_printf( "Count %d - should be %d\n", count, 2*NTIMES );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - loop: Increment a common counter 'n' times
**
**  Description:
**	This will increment a common variable the number of times requsted. 
**	We use the bi_set32/bi_deref32 functions to override any compiler
**	optimizations.
**
****************************************************************************/
static void loop( void *mutex )
{
	int 	i;

	for (i = 0; i < NTIMES; i ++) {
		mp_sem_acquire( mutex, MP_SEM_FOREVER );
		bi_set32( &count, bi_deref32( &count ) + 1 );
		mp_sem_release( mutex );
	}
}
