/***************************************************************************
**
** File: mpex4.c - Illustrates the use of semaphores for sequential execution
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This shows how two semaphores can be utilized to ensure sequential access
** and/or execution of processor code.
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

unsigned long		count = 0L;

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void remote_function( void *param );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: Illustrates use of two semaphores for sequential execution
**
**  Description:
**	This shows how to use two semaphores for accessing data in a sequential
**	manner (first one processor has access then the other). This is different
**	from mpex3 in that there were no guarantees that a single processor could
**	perform many updates prior to the other. This illustrates how to ensure
**	"fair" access.
**
****************************************************************************/
int main( void )
{
	void	*sems[2];
	int 	res;
	int		stepping;

	/*--- Must run on XP processors ---*/

	if (bi_query_cpu_type( &stepping ) != 2) {
		mp_printf( "This requires XP processors to illustrate, exitting\n" );
		exit( 1 );
	}

	/*--- create semaphores ---*/

	sems[0] = mp_sem_allocate ();
	mp_assert( sems[0] != NULL );
	sems[1] = mp_sem_allocate ();
	mp_assert( sems[1] != NULL );

	/*--- set them both to unavailable ---*/

	mp_sem_acquire( sems[0], MP_SEM_FOREVER );
	mp_sem_acquire( sems[1], MP_SEM_FOREVER );

	/*--- start thread on P1 ---*/

	res = mp_thread_start( 1, remote_function, (void *)sems );
	mp_assert( res == 0 );

	/*--- execute sequenced execution by using semaphores ---*/

	for (;;) {
		/*--- Wait to be released by P1 ---*/

		mp_sem_acquire( sems[1], MP_SEM_FOREVER );

		/*--- Increment count, terminate if done ---*/

		if (++count > 10)
			break;

		/*--- release P1 ---*/

		mp_sem_release( sems[0] );
	}

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - remote_function: Display counts as they are updated
**
**  Description:
**	This displays the count contents each time it is updated by processor 0.
**
****************************************************************************/
static void remote_function( void *param )
{
	void	**sems = (void **)param;

	for (;;) {
		/*--- release P0 ---*/

		mp_sem_release( sems[1] );

		/*--- wait to be released by P0 ---*/

		mp_sem_acquire( sems[0], MP_SEM_FOREVER );

		/*--- print current value of count ---*/

		mp_printf( "Count is %d\n", count );
	}
}
