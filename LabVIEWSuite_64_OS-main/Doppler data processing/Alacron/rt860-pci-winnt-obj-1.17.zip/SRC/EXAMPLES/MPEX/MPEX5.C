/***************************************************************************
**
** File: mpex5.c: Illustrates the use of 4MB aliased addresses.
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This shows how 4MB pages can assist in speeding up applications which
** exhibit a high degree of locality of reference. Each time the TLB of an
** i860 does not have a match for the next reference there is extra time
** required to fill it. Using 4MB pages the number of TLB misses is greatly
** reduced when accessing data within a 4MB region.
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

#define N	1024

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void transpose( float *a, int n );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: setup to do 4KB vs. 4MB reference comparisons.
**
**  Description:
**	This will allocate two arrays and perform matrix transpositions on them.
**	The difference between the two operations is provided as output.
**
****************************************************************************/
int main( void )
{
	int 	i;
	float 	*p4K;
	float 	*p4M;
	double 	tstart;
	double 	tend;
	double 	telapsed4K;
	double 	telapsed4M;
	float 	result;
	int		stepping;

	/*--- Must run on XP processors ---*/

	if (bi_query_cpu_type( &stepping ) != 2) {
		mp_printf( "This requires XP processors to illustrate, exitting\n" );
		exit( 1 );
	}

	/*--- initialize timer ---*/

	rtcioctl( RTC_SETFREQ, 0xFFFFFFFF );

	/*--- allocate an N x N array of floats ---*/

	p4K = (float *)malloc( N*N*sizeof(float) );
	mp_assert( p4K != NULL );

	/*--- compute the corresponding 4 Mbyte, Write-Back cached address ---*/

	p4M = (float *)mp_4meg_addr( p4K, MP_KADDR_WBC );
	mp_assert( p4M != NULL );

	/*--- get start time, call transpose 10 times, using 4 Kbyte pages ---*/

	tstart = mp_clock_val( );
	for (i = 0; i < 10; i ++)
		transpose( p4K, N );

	/*--- get stop time, print results ---*/

	tend = mp_clock_val( );
	telapsed4K = (tstart - tend) * 1.0e-6;
	mp_printf( "4 Kbyte pages: Elapsed: %.6f sec\n", telapsed4K );


	/*--- get start time, call transpose 10 times, using 4 Mbyte pages ---*/

	tstart = mp_clock_val( );
	for (i = 0; i < 10; i ++)
		transpose( p4M, N );

	/*--- get stop time, print results ---*/

	tend = mp_clock_val( );
	telapsed4M = (tstart - tend) * 1.0e-6;
	mp_printf( "4 Mbyte pages: Elapsed: %.6f sec\n", telapsed4M );

	/*--- compute percentage improvement ---*/

	mp_printf( "Improved by %.2f percent\n", 
		((telapsed4K - telapsed4M) / telapsed4M) * 100.0);

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - transpose: Matrix transposition
**
**  Description:
**	Implements a simple matrix transposition algorithm.
**
****************************************************************************/
static void transpose( float *a, int n )
{	
	float 	*p1;
	float 	*p2;
	float 	tmp;
	int 	i, j;

	for (i = 0; i < n; i ++) {
		p1 = p2 = a;
		for (j = i; j < n; j ++) {
			tmp = *p1, *p1 = *p2, *p2 = tmp;
			p1 ++;
			p2 += n;
		}
		
		a = a + n + 1;
	}
}
