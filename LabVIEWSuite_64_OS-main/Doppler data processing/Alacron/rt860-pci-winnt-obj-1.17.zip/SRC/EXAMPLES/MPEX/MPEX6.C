/***************************************************************************
**
** File: Illustrates use of mp_clock val for fine-grain-timing.
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This performs dot products on small data sets and calculates the times
** using mp_clock_val.
**
** History:
** 15 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

#define N			100000
#define CLK_PERIOD	1.0e-6

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void dotpr( float *p1, int s1, float *p2, int s2, float *p3, int n );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: Times dot products using mp_clock_val
**
**  Description:
** 	This times a simple dot product of small data sets using mp_clock_val.
**
****************************************************************************/
int main( void )
{
	double 	tstart;
	double 	tend;
	double 	telapsed;
	float 	nops;
	float 	*p1;
	int 	i;
	float 	result;
	int		stepping;

	/*--- Must run on XP processors ---*/

	if (bi_query_cpu_type( &stepping ) != 2) {
		mp_printf( "This requires XP processors to illustrate, exitting\n" );
		exit( 1 );
	}
	
	/*--- Initialize 32 bit counter ---*/

	rtcioctl( RTC_SETFREQ, 0xFFFFFFFF );

	/*--- Allocate and initialize an array of N floats ---*/

	p1 = (float *)malloc( N*sizeof(float) );
	for (i = 0; i < N; i ++)
		p1[i] = ((float)(rand () & 0x7FFF)) / 32768.0;

	/*--- Mark start time ---*/

	tstart = mp_clock_val( );

	/*--- Execute benchmark ---*/

	dotpr( p1, 1, p1, 1, &result, N );

	/*--- Mark stop time ---*/
	
	tend = mp_clock_val( );

	/*--- Compute elapsed time ---*/

	telapsed = (tstart - tend) * CLK_PERIOD;

	/*--- display results ---*/

	mp_printf( "Elapsed: %.6f sec\n", telapsed );
	nops = N*2;
	mp_printf( "%.2f Mflops\n", (nops / telapsed) / 1.0e6 );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - dotpr: Simple dot product implementation
**
**  Description:
**	This will compute the dot product of p1 and p2, for length n, using
**	strides s1 and s2 to index p1 & p2 respectively; the result is stored
**	in *p3.
**
****************************************************************************/
static void dotpr( float *p1, int s1, float *p2, int s2, float *p3, int n )
{
	float sum = 0.0;

	while (n --) {
		sum += *p1 * *p2;
		p1 += s1;
		p2 += s2;
	}
	*p3 = sum;
}
