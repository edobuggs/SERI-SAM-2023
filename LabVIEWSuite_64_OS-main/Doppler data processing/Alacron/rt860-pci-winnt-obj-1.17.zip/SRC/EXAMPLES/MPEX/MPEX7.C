/***************************************************************************
**
** File: mpex7.c - Illustrates interprocessor interrupt handling
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This shows how interprocessor interrupts can be generated and received.
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

typedef struct {
	unsigned long	iflag;
	unsigned long 	procid;
} int_info_t;

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

int_info_t info;

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void remote_int_handler( int procid );
static void remote_function( void *sem );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: start thread on P1, generate interrupt
**
**  Description:
**	This will generate an interrupt to processor 1
**
****************************************************************************/
int main( void )
{
	int 	res;
	void 	*sem;
	int		stepping;

	/*--- Must run on XP processors ---*/

	if (bi_query_cpu_type( &stepping ) != 2) {
		mp_printf( "This requires XP processors to illustrate, exitting\n" );
		exit( 1 );
	}

	/*--- create a semaphore, mark as unavailable ---*/

	sem = mp_sem_allocate( );
	mp_assert( sem != NULL );
	mp_sem_acquire( sem, MP_SEM_FOREVER );

	/*--- start thread on P1 ---*/

	res = mp_thread_start( 1, remote_function, sem );
	mp_assert( res == 0 );

	/*--- wait to be released by P1 ---*/

	mp_sem_acquire( sem, MP_SEM_FOREVER );

	/*--- send interrupt to P1 ---*/

	mp_printf( "P0 sending interrupt\n" );
	mp_gen_int( 1 );

	mp_thread_query( 1, 1 );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - remote_int_handler: Handler for IPC interrupts
**
**  Description:
**	This will handle interrupts from other processors.
**
****************************************************************************/
static void remote_int_handler( int procid )
{
	info.iflag = 1;
	info.procid = procid;
}

/****************************************************************************
**
**  PRIVATE - remote_function: processor 1 thread code
**
**  Description:
**	This is the thread code for processor 1: it sets up to catch interrupts
**	from processor 0, lets processor 0 know it is ready (using a semaphore)
**	and waits to be interrupted.
**
****************************************************************************/
static void remote_function( void *sem )
{
	info.iflag = 0;
	info.procid = -1;

	/*--- Setup to catch interrupt ---*/

	mp_catch_int( 0, remote_int_handler );

	/*--- release P0 ---*/

	mp_sem_release( sem );

	/*--- wait on interrupted flag ---*/

	while (bi_deref32( &info.iflag ) == 0)
		;

	/*--- print out result ---*/

	mp_printf( "P1 received interrupt from processor %d\n", info.procid );
}
