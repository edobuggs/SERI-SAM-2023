/***************************************************************************
**
** File: mpex8: Illustrates mp_printf call
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This simply illustrates both processors being able to generate output
** to the display.
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void remote_function( void *param );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: code to start the same thread on both procs
**
**  Description:
**	This will start both processors on the same code.
**
****************************************************************************/
int main( void )
{
	int res;
	int	stepping;

	/*--- Must run on XP processors ---*/

	if (bi_query_cpu_type( &stepping ) != 2) {
		mp_printf( "This requires XP processors to illustrate, exitting\n" );
		exit( 1 );
	}

	/*--- start thread ---*/

	res = mp_thread_start( 1, remote_function, (void *)0 );
	mp_assert( res == 0 );

	/*--- P0 call's same function ---*/

	remote_function( (void *)0 );

	/*--- wait for P1 to complete ---*/

	mp_thread_query( 1, 1 );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  PRIVATE - remote_function: used by both procs to display
**
**  Description:
**	This just does an mp_printf - showing that both processors can issue
**	this simultaneously...
**
****************************************************************************/
static void remote_function( void *param )
{
	mp_printf( "Hello world from processor %d\n", mp_proc_id() );
}
