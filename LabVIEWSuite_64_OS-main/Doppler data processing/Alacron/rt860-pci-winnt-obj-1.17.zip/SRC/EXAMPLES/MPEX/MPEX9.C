/***************************************************************************
**
** File: mpex9.c - illustrate multiple MP concepts
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This is a more complete example of MP concepts including the use
** of write through cached addresses for simple sharing of data.
**
** History:
** 17 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "i860lib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

#define N	102400

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*--- Declare results data structure ---*/

typedef struct {
	float 	low;
	float 	high;
	int 	lowidx;
	int 	highidx;
} result_t;

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

float 		*pdata0;		/* data set for P0 */
float 		*pdata1;		/* data set for 1 */

result_t 	*pres0;			/* results for P0 */
result_t 	*pres1;			/* results for 1 */

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

static void remote_function( void *param );
static void dostats( float *p, int n, result_t *pres );

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/*----------------------- PRIVATE ROUTINES --------------------------------*/

/****************************************************************************
**
**  EXPORT - main: Allocate data & start both threads.
**
**  Description:
**	This will allocate all of the necessary data and start both processors
**	executing the selection code.
**
****************************************************************************/
int main( void )
{
	int 	res;
	int 	i;
	int		stepping;

	/*--- Must run on XP processors ---*/

	if (bi_query_cpu_type( &stepping ) != 2) {
		mp_printf( "This requires XP processors to illustrate, exitting\n" );
		exit( 1 );
	}

	/*--- allocate results, 32 byte aligned, Write-Through ---*/

	pres0 = (result_t *)mp_4meg_addr(umalloc(sizeof(result_t)), MP_KADDR_WTC);
	mp_assert( pres0 != NULL );

	pres1 = (result_t *)mp_4meg_addr(umalloc(sizeof(result_t)), MP_KADDR_WTC);
	mp_assert( pres1 != NULL );

	/*--- allocate data, 32 byte aligned, Write-Back ---*/

	pdata0 = (float *)mp_4meg_addr(umalloc(N*sizeof(float)), MP_KADDR_WBC);
	mp_assert( pdata0 != NULL );

	pdata1 = (float *)mp_4meg_addr(umalloc(N*sizeof(float)), MP_KADDR_WBC);
	mp_assert( pdata1 != NULL );

	/*--- initialize data ---*/

	for (i = 0; i < N; i ++) {
		pdata0[i] = (float)(rand( ) & 0xffff); 
		pdata1[i] = (float)(rand( ) & 0xffff); 
	}

	/*--- flush so that 1 can see data ---*/

	flush( );
	
	/*--- start 'remote_function' on 1 ---*/

	res = mp_thread_start( 1, remote_function, (void *)0);
	mp_assert( res == 0 );


	/*--- P0 does it share of work ---*/

	dostats( pdata0, N, pres0 );

	/*--- P0 waits for 1 to complete ---*/

	mp_thread_query( 1, 1 );

	/*--- P0 prints all results ... since results are in write-through
		cached memory, no special action is required by 1 to make
		cache coherent ---*/

	mp_printf( "data 0: low %8f high %8f lowidx %6d highidx %6d\n",
		pres0->low, pres0->high, pres0->lowidx, pres0->highidx );

	mp_printf( "data 1: low %8f high %8f lowidx %6d highidx %6d\n",
		pres1->low, pres1->high, pres1->lowidx, pres1->highidx );

	return 0;
		
}

/****************************************************************************
**
**  PRIVATE - dostats: Accumulate statistics
**
**  Description:
**  dostats traverses it's input array, determines the minimum and maximum 
**	values and indices in the array.
**
****************************************************************************/
static void dostats( float *p, int n, result_t *pres )
{
	int 	i;
	int 	lowidx = 0;
	int 	highidx = 0;
	float 	low = p[0];
	float 	high = p[0];

	for (i = 1; i < n; i ++) {
		if (p[i] < low) {
			low = p[i];
			lowidx = i;
			continue;
		}
		if (p[i] > high) {
			high = p[i];
			highidx = i;
		}
	}

	/*--- write results ---*/

	pres->low = low;
	pres->high = high;
	pres->lowidx = lowidx;
	pres->highidx = highidx;
}

/****************************************************************************
**
**  PRIVATE - remote_function: Start point for thread execution
**
**  Description:
**	This bounces us into dostats to do the real work.
**
****************************************************************************/
static void remote_function( void *param )
{
	dostats( pdata1, N, pres1 );
}
