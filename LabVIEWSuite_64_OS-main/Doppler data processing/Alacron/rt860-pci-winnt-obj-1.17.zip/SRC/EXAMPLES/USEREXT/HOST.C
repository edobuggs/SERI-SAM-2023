/***************************************************************************
**
** File: host.c - Host control program for user extensibility example
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This is how a host program handle user extensibility (through it's 
** linkage with the application specific userstub.c)
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "allib.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*
 * ALACRON device specifier
 */
#define AL_DEV			0

/*
 * I860 program to download
 */
#define I860PROGRAM		"i860"

/*
 * Default stack size
 */
#define STACKSIZE		(64L * 1024L)

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main: Program to download and execute i860 program
**
**  Description:
** 	This will open and select a device, download a simple program and
**	check a shared string before and after the alcall invocation.
**
****************************************************************************/
int main( void )
{
	if (alopen (AL_DEV) != SUCCESS)
		errexit( "Can't open AL860 device %d\n", AL_DEV );
	if (aldev( AL_DEV ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit( "Can't select device %d\n", AL_DEV ); 
	}

	if (almapload( I860PROGRAM, STACKSIZE ) != SUCCESS) {
		(void)alclose( AL_DEV );
		errexit ("Can't load %s\n", I860PROGRAM);
	}

	alcall( aladdr( "_main" ), 0 );
	alwait( );

	alclose( AL_DEV );

	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
