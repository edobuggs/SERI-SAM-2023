/***************************************************************************
**
** File: i860.c - board program to illustrate userextensibility
**
** Copyright (C) 1995; Alacron Inc.
**
** Description:
** This will invoke the usertrap function to generate an application specific
** system call code to the host, which is executed by code added to the
** usertrap stub.
**
** History:
** 16 Aug 95, adb: Commenting
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - main:
**
**  Description:
**  Use printf and the usertrap function
**
****************************************************************************/
int main( void )
{
	printf( "hello world\n" );
	usertrap( 2002, 1, 2, 3 );
	return 0;
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
