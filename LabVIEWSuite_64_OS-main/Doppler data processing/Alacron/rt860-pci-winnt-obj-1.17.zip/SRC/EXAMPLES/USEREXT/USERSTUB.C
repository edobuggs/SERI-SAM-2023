/***************************************************************************
**
** File: userstub.c - default user system call support
**
** Copyright (C) 1991-1995; Alacron Inc.
**
** Description:
** This contains the default user system call support interfaces, it should
** be modified to install customer required interfaces.
**
** History:
**  1 Aug 95, adb: Formatting
** 16 Aug 95, adb: Converted for user example
**
****************************************************************************/

/*----------------------- HEADER FILES ------------------------------------*/

#include <stdio.h>
#include "privhost.h"

/*----------------------- PRIVATE CONSTANTS -------------------------------*/

/*----------------------- PRIVATE MACROS ----------------------------------*/

/*----------------------- PRIVATE TYPES -----------------------------------*/

/*----------------------- PRIVATE DATA ------------------------------------*/

/*----------------------- PUBLIC DATA -------------------------------------*/

/*----------------------- PRIVATE ROUTINE REFERENCES ----------------------*/

/*----------------------- PUBLIC ROUTINES ---------------------------------*/

/****************************************************************************
**
**  EXPORT - usersys: User supplied system call support interface
**
**  Description:
**	This routine can be modified to implement application specific
**	"system" calls. The identifier for the user supplied system call
**	is passed in "code", and the array of optional arguments
**	from usertrap.
**
**	The interface routine setresult should be used to indicate the 
**	return code for this routine.
**
****************************************************************************/
void API usersys( int code, long *sysargs )
{
	int 	i;

	switch (code)
	{
	case 2002:
		printf ("userx %d: %ld %ld %ld\n", code, sysargs[0], sysargs[1],
			sysargs[2]);
		break;
	default:
		printf("usersys: unimplemented function %x/%d\n", code,code );
		for (i = 0; i < 4; i++)
			printf("\t%08lx (%8d)\n", sysargs[i], sysargs[i]);
		setresult( -1 );
		break;
	}
}

/****************************************************************************
**
**  EXPORT - userinit: Userinitialization routine
**
**  Description:
**	This routine can be modified to perform other application specific
**	initializations for a user extensible program.
**
****************************************************************************/
void userinit(USER_INIT *pu )
{
	_userinit(pu);
}

/*----------------------- PRIVATE ROUTINES --------------------------------*/
