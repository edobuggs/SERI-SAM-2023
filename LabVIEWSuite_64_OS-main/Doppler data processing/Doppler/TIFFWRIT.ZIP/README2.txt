TIFFWRIT.LLB 

Contains two VIs, one for converting an intensity graph to RGB values
and another for writing the TIFF file.  TIFF files have a complex file
format that requires a lot of identifying information (see the
description in the cluster for image info for details).  This VI does
the bare bones necessary to write a TIFF file.  Its structure will make
it easy to extend it for more sophisticated needs.  A reference is given
to the book that I used to understand the format.

The software is provided as is, please respect my copyright.

Thanks, 
David Moschella
Ellipsis,  Inc.


(c) 1997 Copyright Ellipsis, Inc.
All Rights Reserved.
May be used for non-commercial applications within your organization.
If incorporated in whole or in part into a product for sale, then you must
contact Ellipsis, Inc., 412 Columbus Avenue, Boston MA  (617) 236-0141
for a license to use this software.